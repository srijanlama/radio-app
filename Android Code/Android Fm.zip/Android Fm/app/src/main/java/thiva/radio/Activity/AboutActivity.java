package thiva.radio.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import thiva.radio.Constant.Constant;
import thiva.radio.Methods.Methods;
import thiva.radio.R;
import thiva.radio.SharedPre.Setting;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class AboutActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView  company, email, website, contact;
    private Methods methods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Setting.Dark_Mode) {
            setTheme(R.style.AppTheme2);
        } else {
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        methods = new Methods(this);
        methods.showInter();
        methods.forceRTLIfSupported(getWindow());

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        methods.Toolbar_Color(toolbar,getWindow(),getSupportActionBar(), "");
        methods.setStatusBar(getWindow());

        company = findViewById(R.id.company);
        email = findViewById(R.id.email);
        website = findViewById(R.id.website);
        contact = findViewById(R.id.contact);

        company.setText(Setting.company);
        email.setText(Setting.email);
        website.setText(Setting.website);
        contact.setText(Setting.contact);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}