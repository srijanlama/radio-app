package thiva.radio.Receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import java.io.IOException;

import thiva.radio.Activity.FmActivity;
import thiva.radio.Activity.PlayService;
import thiva.radio.R;
import thiva.radio.SharedPre.Setting;
import thiva.radio.SharedPre.SharedPref;

import static thiva.radio.Activity.PlayService.ACTION_STOP;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class MyReceiver extends BroadcastReceiver {

    SharedPref sharedPref;

    @Override
    public void onReceive(final Context context, Intent intent) {
        sharedPref = new SharedPref(context);

        try {
            if (sharedPref.getIsSleepTimeOn()) {
                sharedPref.setSleepTime(false, 0, 0);
                if (!Setting.canRecordNew) {
                    try {
                        Setting.fileOutputStream.flush();
                        Setting.fileOutputStream.close();
                        Setting.inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (Setting.Dark_Mode) {
                        FmActivity.imageView_record.setImageResource(R.drawable.ic_microphone2);
                    } else {
                        FmActivity.imageView_record.setImageResource(R.drawable.ic_microphone);
                    }
                    Setting.canRecordNew = true;
                }

                if (PlayService.getInstance() != null) {
                    FmActivity.imageView_play.setBackgroundResource(R.drawable.ic_play_arrow_white_24dp);
                    intent = new Intent(context, PlayService.class);
                    intent.setAction(ACTION_STOP);
                    context.startService(intent);
                    Toast.makeText(context, "Time End Stop Audio", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(context, "Time End Stop Audio", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}