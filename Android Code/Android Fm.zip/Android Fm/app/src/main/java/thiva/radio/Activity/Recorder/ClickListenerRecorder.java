package thiva.radio.Activity.Recorder;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public interface ClickListenerRecorder {
    void onClick(int position);
}
