package thiva.radio.Constant;

import java.io.Serializable;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class Constant implements Serializable {

    public static String SAVER_URL = "https://admin.thivapro.com/Single_Radio/wp-admin/";
}