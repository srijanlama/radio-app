package thiva.radio.Activity.Recorder;


import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;

import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

import thiva.radio.R;
import thiva.radio.SharedPre.Setting;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class AdapterRecorder extends RecyclerView.Adapter<AdapterRecorder.MyViewHolder> {

    private Context context;
    private ArrayList<ItemRecorder> arrayList;
    private ArrayList<ItemRecorder> filteredArrayList;
    private ClickListenerRecorder recyclerClickListener;
    private NameFilter filter;
    private String type;

    DefaultBandwidthMeter bandwidthMeter;
    DataSource.Factory dataSourceFactory;
    ExtractorsFactory extractorsFactory;

    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView tv_title, tv_artist, views;
        public ImageView play, pause, option;
        RelativeLayout linearLayout;


        MyViewHolder(View view) {
            super(view);

            tv_title = itemView.findViewById(R.id.tv_songlist_name);
            tv_artist =  itemView.findViewById(R.id.tv_songlist_cat);
            linearLayout = itemView.findViewById(R.id.thiva);
            play = itemView.findViewById(R.id.play);
            pause = itemView.findViewById(R.id.pause);
            views = itemView.findViewById(R.id.tv_songlist_vie);
            option = itemView.findViewById(R.id.iv_option);

        }
    }

    public AdapterRecorder(Context context, ArrayList<ItemRecorder> arrayList, ClickListenerRecorder recyclerClickListener, String type) {
        this.arrayList = arrayList;
        this.filteredArrayList = arrayList;
        this.context = context;
        this.type = type;
        this.recyclerClickListener = recyclerClickListener;

        bandwidthMeter = new DefaultBandwidthMeter();
        TrackSelection.Factory videoTrackSelectionFactory =
                new AdaptiveTrackSelection.Factory(bandwidthMeter);
        TrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);
        dataSourceFactory = new DefaultDataSourceFactory(context, Util.getUserAgent(context, "nemosofts_dow"), bandwidthMeter);
        extractorsFactory = new DefaultExtractorsFactory();

        Setting.exoPlayer = ExoPlayerFactory.newSimpleInstance(context, trackSelector);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_racorder_songs, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

        final ItemRecorder song = arrayList.get(position);

        holder.tv_title.setText(song.getTitle());
        holder.tv_artist.setText(song.getDuration());
        holder.views.setText(getStringSizeLengthFile(song.getFilesize()));

        final String finalUrl =  song.getMp3();

        Setting.exoPlayer.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest, int reason) {
            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
                Log.v("v", "onTracksChanged");
            }

            @Override
            public void onLoadingChanged(boolean isLoading) {
                Log.v("v", "onLoadingChanged");

            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
                if (playbackState == Player.STATE_ENDED) {
                    holder.play.setVisibility(View.VISIBLE);
                    holder.pause.setVisibility(View.GONE);
                }
                if (playbackState == Player.STATE_READY && playWhenReady) {
                }
                Log.v("v", "onRepeatModeChanged" + playbackState + "-" + ExoPlayer.STATE_READY);
            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {
                Log.v("v", "onRepeatModeChanged");
            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {
                Log.v("v", "onPlayerError");
                Setting.exoPlayer.setPlayWhenReady(false);
            }

            @Override
            public void onPositionDiscontinuity(int reason) {
            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
                Log.v("v", "onPlaybackParametersChanged");
            }

            @Override
            public void onSeekProcessed() {
            }

        });


        holder.pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Setting.exoPlayer.getPlayWhenReady()) {
                    Setting.exoPlayer.setPlayWhenReady(false);
                    Picasso.get()
                            .load(R.drawable.play_r)
                            .placeholder(R.drawable.play_r)
                            .into(holder.pause);
                } else {
                    Setting.exoPlayer.setPlayWhenReady(true);
                    Picasso.get()
                            .load(R.drawable.pause_r)
                            .placeholder(R.drawable.pause_r)
                            .into(holder.pause);
                }
            }
        });


        holder.play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerClickListener.onClick(getPosition(arrayList.get(holder.getAdapterPosition()).getId()));

                MediaSource mediaSource;
                if (finalUrl.endsWith("_Other")) {
                    finalUrl.replace("_Other", "");
                }

                dataSourceFactory = new DefaultDataSourceFactory(context, Util.getUserAgent(context, "nemosofts_dow"), bandwidthMeter);
                mediaSource = new ExtractorMediaSource(Uri.parse(finalUrl),
                        dataSourceFactory, extractorsFactory, null, null);
                Setting.exoPlayer.prepare(mediaSource);

                Setting.exoPlayer.setPlayWhenReady(true);


                Picasso.get()
                        .load(R.drawable.pause_r)
                        .placeholder(R.drawable.pause_r)
                        .into(holder.pause);

                Picasso.get()
                        .load(R.drawable.play_r)
                        .placeholder(R.drawable.play_r)
                        .into(holder.play);


                holder.play.setVisibility(View.GONE);
                holder.pause.setVisibility(View.VISIBLE);

            }
        });


        if (Setting.exoPlayer.getPlayWhenReady() & Setting.arrayList_play_rc.get(Setting.playPos_rc).getId().equals(arrayList.get(position).getId())) {
            holder.play.setVisibility(View.GONE);
            holder.pause.setVisibility(View.VISIBLE);
        } else {
            holder.pause.setVisibility(View.GONE);
            holder.play.setVisibility(View.VISIBLE);
        }

        holder.option.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openOptionPopUp(holder.option, holder.getAdapterPosition());
            }
        });

    }


    public static String getStringSizeLengthFile(long size) {
        DecimalFormat df = new DecimalFormat("0.00");

        float sizeKb = 1024.0f;
        float sizeMb = sizeKb * sizeKb;
        float sizeGb = sizeMb * sizeKb;
        float sizeTerra = sizeGb * sizeKb;

        if(size < sizeMb)
            return df.format(size / sizeKb)+ " Kb";
        else if(size < sizeGb)
            return df.format(size / sizeMb) + " Mb";
        else if(size < sizeTerra)
            return df.format(size / sizeGb) + " Gb";

        return "";
    }


    private void openOptionPopUp(ImageView imageView, final int pos) {
        Context wrapper = new ContextThemeWrapper(context, R.style.YOURSTYLE);
        android.widget.PopupMenu popup = new android.widget.PopupMenu(wrapper, imageView);
        popup.getMenuInflater().inflate(R.menu.popup_song_off, popup.getMenu());

        popup.setOnMenuItemClickListener(new android.widget.PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.popup_delete:
                        openDeleteDialog(pos);
                        break;
                }
                return true;
            }
        });
        popup.show();
    }

    private void openDeleteDialog(final int pos) {
        final File file = new File(arrayList.get(pos).getMp3());
        AlertDialog.Builder dialog;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Setting.Dark_Mode){
                dialog = new AlertDialog.Builder(context, R.style.ThemeDialog2);
            }else {
                dialog = new AlertDialog.Builder(context, R.style.ThemeDialog);
            }
        } else {
            dialog = new AlertDialog.Builder(context);
        }
        dialog.setTitle(context.getString(R.string.delete));
        dialog.setMessage(context.getString(R.string.sure_delete));
        dialog.setPositiveButton(context.getString(R.string.delete), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                final String where = MediaStore.MediaColumns.DATA + "=?";
                final String[] selectionArgs = new String[] {
                        file.getAbsolutePath()
                };
                final ContentResolver contentResolver = context.getContentResolver();
                final Uri filesUri = MediaStore.Files.getContentUri("external");

                contentResolver.delete(filesUri, where, selectionArgs);

                if (file.exists()) {

                }

                try {
                    contentResolver.delete(filesUri, where, selectionArgs);
                    file.delete();
                    notifyDataSetChanged();
                    arrayList.remove(pos);
                    notifyItemRemoved(pos);
                    Toast.makeText(context, context.getString(R.string.file_deleted), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        dialog.setNegativeButton(context.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        dialog.show();
    }


    @Override
    public long getItemId(int id) {
        return id;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public ItemRecorder getItem(int pos) {
        return arrayList.get(pos);
    }

    private int getPosition(String id) {
        int count=0;
        for(int i=0;i<filteredArrayList.size();i++) {
            if(id.equals(filteredArrayList.get(i).getId())) {
                count = i;
                break;
            }
        }
        return count;
    }


    private class NameFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            constraint = constraint.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (constraint.toString().length() > 0) {
                ArrayList<ItemRecorder> filteredItems = new ArrayList<>();

                for (int i = 0, l = filteredArrayList.size(); i < l; i++) {
                    String nameList = filteredArrayList.get(i).getTitle();
                    if (nameList.toLowerCase().contains(constraint))
                        filteredItems.add(filteredArrayList.get(i));
                }
                result.count = filteredItems.size();
                result.values = filteredItems;
            } else {
                synchronized (this) {
                    result.values = filteredArrayList;
                    result.count = filteredArrayList.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            arrayList = (ArrayList<ItemRecorder>) results.values;
            notifyDataSetChanged();
        }
    }

}