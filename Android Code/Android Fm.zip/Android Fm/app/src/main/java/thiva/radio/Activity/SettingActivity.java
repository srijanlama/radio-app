package thiva.radio.Activity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.nemosofts.library.SwitchButton.SwitchButton;

import java.util.ArrayList;

import thiva.radio.BuildConfig;
import thiva.radio.Color_Pik.ColorPicker;
import thiva.radio.Methods.Methods;
import thiva.radio.R;
import thiva.radio.SharedPre.Setting;
import thiva.radio.SharedPre.SharedPref;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class SettingActivity extends AppCompatActivity {

    private SharedPref sharedPref;
    private Methods methods;
    private SwitchButton switch_dark, Switch_StatusBar,switch_as;
    private Toolbar toolbar;
    private TextView version;
    private ImageView color_image;
    private LinearLayout about, share,privacy,coler_pik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPref = new SharedPref(this);
        if (sharedPref.getNightMode()) {
            setTheme(R.style.AppTheme2);
            Setting.Dark_Mode = true;
        } else {
            setTheme(R.style.AppTheme);
            Setting.Dark_Mode = false;
        }
        if (sharedPref.getStatusBar()) {
            Setting.StatusBar = true;
        } else {
            Setting.StatusBar = false;
        }
        if (sharedPref.getToolbar_Color()) {
            Setting.ToolBar_Color = true;
        } else {
            Setting.ToolBar_Color = false;
        }
        Setting.get_color_my = sharedPref.getColor_my();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        methods = new Methods(this);
        methods.showInter();
        methods.forceRTLIfSupported(getWindow());

        color_image = findViewById(R.id.color);
        color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.Toolbar_1)));

        toolbar = findViewById(R.id.toolbar_setting);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Setting");

        this.setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        methods.Toolbar_Color(toolbar,getWindow(),getSupportActionBar(),"");
        methods.setStatusBar(getWindow());
        methods.Set_color_image(color_image);

        Dark_mode();

        about= findViewById(R.id.nav_about);
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent player = new Intent(SettingActivity.this,AboutActivity.class);
                startActivity(player);
            }
        });

        share  = findViewById(R.id.nav_share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String appName = getPackageName();
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + appName)));
            }
        });

        privacy  = findViewById(R.id.nav_privacy);
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent PrivacyPolicy = new Intent(SettingActivity.this,PrivacyPolicyActivity.class);
                startActivity(PrivacyPolicy);
            }
        });

        RelativeLayout feedback = findViewById(R.id.feedback);
        feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Feedback = new Intent(SettingActivity.this,FeedbackActivity.class);
                startActivity(Feedback);
            }
        });

        Switch_StatusBar();

        version =  findViewById(R.id.version);

        version.setText(BuildConfig.VERSION_NAME);
        switch_as();

        coler_pik  = findViewById(R.id.coler_pik);
        coler_pik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog_coler_pik();
            }
        });

        if (Setting.ToolBar_Color2){
            Setting.ToolBar_Color2 = false;
            Apps_recreate();
        }
        if (Setting.ToolBar_Color3){
            Setting.ToolBar_Color3 = false;
            Apps_recreate();
        }
    }


    private void Dialog_coler_pik() {
        final ColorPicker colorPicker = new ColorPicker(SettingActivity.this);
        ArrayList<String> colors = new ArrayList<>();
        colors.add("#82B926");
        colors.add("#a276eb");
        colors.add("#6a3ab2");
        colors.add("#666666");
        colors.add("#000000");
        colors.add("#3C8D2F");
        colors.add("#FA9F00");
        colors.add("#FF0000");

        colorPicker
                .setDefaultColorButton(Color.parseColor("#f84c44"))
                .setColors(colors)
                .setColumns(4)
                .setRoundColorButton(true)
                .setOnChooseColorListener(new ColorPicker.OnChooseColorListener() {
                    @Override
                    public void onChooseColor(int position, int color) {
                        sharedPref.setColor_my(position);
                        Setting.ToolBar_Color3 = true;
                        Apps_recreate();
                    }

                    @Override
                    public void onCancel() {
                        Apps_recreate();
                    }
                }).show();
    }
    private void switch_as() {
        switch_as = findViewById(R.id.switch_as);
        if (sharedPref.getToolbar_Color()) {
            switch_as.setChecked(true);
        } else {
            switch_as.setChecked(false);
        }
        switch_as.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                sharedPref.setToolbar_Color(isChecked);
                Setting.ToolBar_Color2 = true;
                Apps_recreate();
            }
        });
    }

    private void Switch_StatusBar() {
        Switch_StatusBar = findViewById(R.id.switch_apps_full);

        if (sharedPref.getStatusBar()) {
            Switch_StatusBar.setChecked(true);
        } else {
            Switch_StatusBar.setChecked(false);
        }

        Switch_StatusBar.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                sharedPref.setStatusBar(isChecked);
                Apps_recreate();
            }
        });
    }

    private void Dark_mode() {
        switch_dark = findViewById(R.id.switch_dark);
        if (sharedPref.getNightMode()) {
            switch_dark.setChecked(true);
        } else {
            switch_dark.setChecked(false);
        }
        switch_dark.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                sharedPref.setNightMode(isChecked);
                Apps_recreate();
            }
        });
    }

    private void Apps_recreate() {
        recreate();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                overridePendingTransition(0, 0);
                overridePendingTransition(0, 0);
                startActivity(new Intent(SettingActivity.this, FmActivity.class));
                finish();
                break;

            default:
                return super.onOptionsItemSelected(menuItem);
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        overridePendingTransition(0, 0);
        overridePendingTransition(0, 0);
        startActivity(new Intent(SettingActivity.this, FmActivity.class));
        finish();
    }
}