package thiva.radio.SharedPre;


import android.content.Context;

import com.google.android.exoplayer2.SimpleExoPlayer;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;

import thiva.radio.Activity.Recorder.ItemRecorder;

import thiva.radio.Constant.Constant;
import thiva.radio.Receiver.ItemNemosofts;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class Setting implements Serializable {

    public static SimpleExoPlayer exoPlayer_Radio;
    public static boolean canRecordNew = true;

    public static String songName = "";
    //-------------------------------------------------------------//
    public static boolean StatusBar = false;
    public static boolean Dark_Mode = false;
    public static Boolean is = false;
    public static ItemNemosofts itemAbout;
    public static boolean ToolBar_Color = false;
    public static boolean ToolBar_Color2 = false;
    public static boolean ToolBar_Color3 = false;
    public static int get_color_my = 0;
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_MSG = "msg";
    public static final String TAG_ROOT = "nemosofts";
    public static String api="speed_api.php";
    public static String SERVER_URL = Constant.SAVER_URL + api;
    public static Context context;
    public static SimpleExoPlayer exoPlayer;
    public static ArrayList<ItemRecorder> arrayList_play_rc = new ArrayList<>();
    public static int playPos_rc = 0;
    public static InputStream inputStream;
    public static FileOutputStream fileOutputStream;
    //-------------------------------------------------------------//

    public static Boolean isAdmobBannerAd = true, isAdmobInterAd = true, isAdmobNativeAd = true, isFBBannerAd = true, isFBInterAd = true, isFBNativeAd = false;
    public static String ad_publisher_id = "";public static String ad_banner_id = "", ad_inter_id = "", ad_native_id = "", fb_ad_banner_id = "", fb_ad_inter_id = "", fb_ad_native_id = "";
    public static int adShow = 5;public static int adShowFB = 5;public static int adCount = 0;public static int admobNativeShow = 5, fbNativeShow = 5;

    public static String purchase_code = "";
    public static String nemosofts_key = "";

    public static String Url_fm = "http://149.202.22.75:8032/live";

    public static Boolean autoplay = true;
    public static Boolean isRTL = false;
    public static Boolean visualizer = false;

    public static String banner_size = "banner_size";public static String banner_size_fb = "banner_size_fb";
    public static String company = "",email = "",website = "",contact = "",facebook_url = "",twiter_url = "",intagram_url = "";
    public static int version=1;public static String version_name="1.0.0";public static String description=""; public static String url="";
    public static final String METHOD_APP_DETAILS = "app_details";
    public static final String METHOD_SUGGESTION = "song_suggest";
    public static final String METHOD_APP_UPDATE = "app_update";


}