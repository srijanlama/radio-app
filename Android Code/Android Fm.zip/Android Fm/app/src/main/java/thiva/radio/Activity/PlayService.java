package thiva.radio.Activity;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.widget.RemoteViews;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;

import java.io.IOException;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.media.session.MediaButtonReceiver;
import saschpe.exoplayer2.ext.icy.IcyHttpDataSource;
import saschpe.exoplayer2.ext.icy.IcyHttpDataSourceFactory;
import thiva.radio.Constant.Constant;
import thiva.radio.Methods.Methods;
import thiva.radio.R;
import thiva.radio.Receiver.HardButtonReceiver;
import thiva.radio.Receiver.MediaButtonIntentReceiver;
import thiva.radio.SharedPre.ParserM3UToURL;
import thiva.radio.SharedPre.Setting;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class PlayService extends Service {

    static private final int NOTIFICATION_ID = 119;
    static private PlayService service;
    static private Context context;
    static NotificationManager mNotificationManager;
    NotificationCompat.Builder mBuilder;
    LoadSong loadSong;
    private Boolean isCanceled = false;
    RemoteViews smallViews;
    Methods methods;
    Bitmap bitmap;
    ComponentName componentName;
    AudioManager mAudioManager;

    PowerManager.WakeLock mWakeLock;
    private HardButtonReceiver mButtonReceiver;

    public static final String ACTION_STOP = "action.STOP";
    public static final String ACTION_PLAY = "action.PLAY";
    public static final String ACTION_TOGGLE = "action.TOGGLE_PLAYPAUSE";

    public void initialize(Context context) {
        PlayService.context = context;
        mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    static public void initNewContext(Context context) {
        PlayService.context = context;
        mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    public static PlayService getInstance() {
        return service;
    }

    public static PlayService createInstance() {
        if (service == null) {
            service = new PlayService();
        }
        return service;
    }

    public Boolean isPlaying() {
        if (service == null) {
            return false;
        } else {
            if (Setting.exoPlayer_Radio != null) {
                return Setting.exoPlayer_Radio.getPlayWhenReady();
            } else {
                return false;
            }
        }
    }

    @Override
    public void onCreate() {
        methods = new Methods(context);
        mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        mAudioManager.requestAudioFocus(onAudioFocusChangeListener, AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);

        componentName = new ComponentName(getPackageName(), MediaButtonIntentReceiver.class.getName());
        mAudioManager.registerMediaButtonEventReceiver(componentName);

        registerReceiver(onHeadPhoneDetect, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));


        DefaultBandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        AdaptiveTrackSelection.Factory trackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);
        DefaultTrackSelector trackSelector = new DefaultTrackSelector(trackSelectionFactory);
        Setting.exoPlayer_Radio = ExoPlayerFactory.newSimpleInstance(getApplicationContext(), trackSelector);
        Setting.exoPlayer_Radio.addListener(eventListener);


        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
        mWakeLock.setReferenceCounted(false);

        IntentFilter iF = new IntentFilter(Intent.ACTION_MEDIA_BUTTON);
        /**
         * Assign the intent filter a high priority so this receiver
         * gets called first on a button press which can then determine
         * whether to pass it down to other apps or not (i.e. the Music app)
         *
         * Initially I found the SYSTEM_HIGH_PRIORITY didn't work, lastfm seemed
         * to get first request of the button press, then the music player and
         * this example didn't get access to it.
         *
         * So while +1 works, its extremely easy to break (i.e. another developer uses
         * SYSTEM_HIGH_PRIORITY + 1 then you may not get access to the button event).
         *
         * Also the Document says to use a value between SYSTEM_LOW_PRIORITY and
         * SYSTEM_HIGH_PRIORITY (i.e. -1000 & 1000)
         */
        iF.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY + 1);
        // register the receiver
        registerReceiver(mButtonReceiver, iF);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            switch (intent.getAction()) {
                case ACTION_STOP:
                    stop(intent);
                    break;
                case ACTION_PLAY:
                    newPlay();
                    break;
                case ACTION_TOGGLE:
                    togglePlayPause();
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return START_NOT_STICKY;
    }

    private class LoadSong extends AsyncTask<String, Void, Boolean> {

        protected void onPreExecute() {
            FmActivity.setBuffer(true);
            FmActivity.changeSongName(getString(R.string.unknown_song));
        }

        protected Boolean doInBackground(final String... args) {
            try {
                String url = Setting.Url_fm;
                MediaSource mediaSource;
                DefaultDataSourceFactory dataSourceFactory = new DefaultDataSourceFactory(getApplicationContext(), null, icy);

                if (url.contains(".m3u8")) {
                    mediaSource = new HlsMediaSource.Factory(dataSourceFactory)
                            .createMediaSource(Uri.parse(url));
                } else if (url.contains(".m3u") || url.contains("yp.shoutcast.com/sbin/tunein-station.m3u?id=")) {
                    url = ParserM3UToURL.parse(url, "m3u");

                    mediaSource = new ExtractorMediaSource.Factory(dataSourceFactory)
                            .setExtractorsFactory(new DefaultExtractorsFactory())
                            .createMediaSource(Uri.parse(url));

                } else if (url.contains(".pls") || url.contains("listen.pls?sid=") || url.contains("yp.shoutcast.com/sbin/tunein-station.pls?id=")) {
                    url = ParserM3UToURL.parse(url, "pls");

                    mediaSource = new ExtractorMediaSource.Factory(dataSourceFactory)
                            .setExtractorsFactory(new DefaultExtractorsFactory())
                            .createMediaSource(Uri.parse(url));
                } else {
                    mediaSource = new ExtractorMediaSource.Factory(dataSourceFactory)
                            .setExtractorsFactory(new DefaultExtractorsFactory())
                            .createMediaSource(Uri.parse(url));
                }

                Setting.exoPlayer_Radio.prepare(mediaSource);
                Setting.exoPlayer_Radio.setPlayWhenReady(true);
                return true;
            } catch (Exception e1) {
                e1.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            if (context != null) {
                super.onPostExecute(aBoolean);
                if (!aBoolean) {
                    FmActivity.setBuffer(false);
                    methods.showToast(getString(R.string.error_loading_radio));
                }
            }
        }
    }

    Player.EventListener eventListener = new Player.DefaultEventListener() {
        @Override
        public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
            if (playbackState == Player.STATE_READY && playWhenReady) {
                if (!isCanceled) {
                    FmActivity.setBuffer(false);
                    if (mBuilder == null) {
                        createNotification();
                    } else {
                        updateNoti();
                    }
                    changePlayPause(true);

                    if (Setting.visualizer){
                        //TODO: init MediaPlayer and play the audio
                        //get the AudioSessionId from your MediaPlayer and pass it to the visualizer
                        int audioSessionId = Setting.exoPlayer_Radio.getAudioSessionId();
                        if (audioSessionId != -1){
                            FmActivity.barVisualizer.setColor(ContextCompat.getColor(context, R.color.colorAccent_Light));
                            FmActivity.barVisualizer.setDensity(50);
                            try {
                                FmActivity.barVisualizer.setPlayer(audioSessionId);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                } else {
                    isCanceled = false;
                    stopExoPlayer();
                }
            }

            if(playWhenReady) {
                if(!mWakeLock.isHeld()) {
                    mWakeLock.acquire(60000);
                }
            } else {
                if(mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
            }
        }

        @Override
        public void onPlayerError(ExoPlaybackException error) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopExoPlayer();
                    stopForeground(true);
                    stopSelf();
                    FmActivity.setBuffer(false);
                    changePlayPause(false);
                }
            }, 0);
            super.onPlayerError(error);
        }

        @Override
        public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
            super.onTracksChanged(trackGroups, trackSelections);
        }
    };

    private String getUserAgent() {
        return "radio";
    }

    private void changePlayPause(Boolean play) {
        if (play) {
            if (PlayService.getInstance() != null) {
                FmActivity.imageView_play.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_pause_white_24dp));
                FmActivity.textView_play.setText(getResources().getString(R.string.textView_pause));
            }
        } else {
            FmActivity.imageView_play.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_play_arrow_white_24dp));
            FmActivity.textView_play.setText(getResources().getString(R.string.textView_play));
        }
    }

    private void togglePlayPause() {
        if (Setting.exoPlayer_Radio.getPlayWhenReady()) {
            pause();
        } else {
            if (methods.isConnectingToInternet()) {
                play();
            } else {
                methods.showToast(getString(R.string.internet_not_connected));
            }
        }
    }

    private void pause() {

        Setting.exoPlayer_Radio.setPlayWhenReady(false);
        changePlayPause(false);
        updateNotiPlay(false);
    }

    private void play() {
        Setting.exoPlayer_Radio.setPlayWhenReady(true);
        changePlayPause(true);
        updateNotiPlay(true);
    }

    private void newPlay() {
        loadSong = new LoadSong();
        loadSong.execute();
    }

    public void stop(Intent intent) {
        if (Setting.exoPlayer_Radio != null) {
            if(!Setting.canRecordNew) {
                try {
                    Setting.fileOutputStream.flush();
                    Setting.fileOutputStream.close();
                    Setting.inputStream.close();
                    if (Setting.Dark_Mode) {
                        FmActivity.imageView_record.setImageResource(R.drawable.ic_microphone2);
                    } else {
                        FmActivity.imageView_record.setImageResource(R.drawable.ic_microphone);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Setting.canRecordNew = true;
            }
            try {
                mAudioManager.abandonAudioFocus(onAudioFocusChangeListener);
                unregisterReceiver(onHeadPhoneDetect);
                mAudioManager.unregisterMediaButtonEventReceiver(componentName);
            } catch (Exception e) {
                e.printStackTrace();
            }
            stopExoPlayer();
            changePlayPause(false);
            service = null;
            stopService(intent);
            stopForeground(true); // delete notification
        }
    }

    public void stopExoPlayer() {
        if (Setting.exoPlayer_Radio != null) {
            Setting.exoPlayer_Radio.setPlayWhenReady(false);
            Setting.exoPlayer_Radio.stop();
            Setting.exoPlayer_Radio.addListener(eventListener);
        }
    }

    private void createNotification() {
        Intent notificationIntent = new Intent(this, FmActivity.class);
        notificationIntent.setAction(Intent.ACTION_MAIN);
        notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        PendingIntent pi = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent playIntent = new Intent(this, PlayService.class);
        playIntent.setAction(ACTION_TOGGLE);
        PendingIntent pplayIntent = PendingIntent.getService(this, 0,
                playIntent, 0);

        Intent closeIntent = new Intent(this, PlayService.class);
        closeIntent.setAction(ACTION_STOP);
        PendingIntent pcloseIntent = PendingIntent.getService(this, 0,
                closeIntent, PendingIntent.FLAG_CANCEL_CURRENT);


        String NOTIFICATION_CHANNEL_ID = "onlinradio_ch_1";
        mBuilder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                .setTicker(getString(R.string.app_name))
                .setContentTitle(getString(R.string.app_name))
                .setContentText(Setting.songName)
                .setContentIntent(pi)
                .setPriority(Notification.PRIORITY_LOW)
                .setSmallIcon(R.drawable.ic_notification)
                .setChannelId(NOTIFICATION_CHANNEL_ID)
                .setOnlyAlertOnce(true);

        NotificationChannel mChannel;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.app_name);// The user-visible name of the channel.
            mChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, name, NotificationManager.IMPORTANCE_LOW);
            mNotificationManager.createNotificationChannel(mChannel);

            MediaSessionCompat mMediaSession;
            mMediaSession = new MediaSessionCompat(context, getString(R.string.app_name));
            mMediaSession.setFlags(
                    MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
                            MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);

            mBuilder.setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                    .setMediaSession(mMediaSession.getSessionToken())
                    .setShowCancelButton(true)
                    .setShowActionsInCompactView(0, 1)
                    .setCancelButtonIntent(
                            MediaButtonReceiver.buildMediaButtonPendingIntent(
                                    context, PlaybackStateCompat.ACTION_STOP)))
                    .addAction(new NotificationCompat.Action(
                            R.drawable.ic_pause_white_24dp, "Pause",
                            pplayIntent))
                    .addAction(new NotificationCompat.Action(
                            R.drawable.ic_close_white_24dp, "Close",
                            pcloseIntent));
        } else {
            smallViews = new RemoteViews(getPackageName(), R.layout.layout_noti_small);
            smallViews.setOnClickPendingIntent(R.id.status_bar_collapse, pcloseIntent);
            smallViews.setOnClickPendingIntent(R.id.status_bar_play, pplayIntent);
            smallViews.setTextViewText(R.id.status_bar_track_name, context.getString(R.string.app_name));
            smallViews.setTextViewText(R.id.status_bar_artist_name, Setting.songName);

            mBuilder.setCustomContentView(smallViews);
        }

        startForeground(NOTIFICATION_ID, mBuilder.build());
        updateNotiImage();
    }

    private void updateNotiImage() {
        new AsyncTask<String, String, String>() {

            @Override
            protected String doInBackground(String... strings) {
                try {

                    getBitmapFromURL();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        mBuilder.setLargeIcon(bitmap);
                    } else {
                        smallViews.setImageViewBitmap(R.id.status_bar_album_art, bitmap);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(String s) {
                mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
                super.onPostExecute(s);
            }
        }.execute();
    }

    private void updateNoti() {
        updateNotiPlay(Setting.exoPlayer_Radio.getPlayWhenReady());
    }

    @SuppressLint("RestrictedApi")
    private void updateNotiPlay(Boolean isPlay) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mBuilder.mActions.remove(0);
            Intent playIntent = new Intent(this, PlayService.class);
            playIntent.setAction(ACTION_TOGGLE);
            PendingIntent ppreviousIntent = PendingIntent.getService(this, 0, playIntent, 0);
            if (isPlay) {
                mBuilder.mActions.add(0, new NotificationCompat.Action(
                        R.drawable.ic_pause_white_24dp, "Pause",
                        ppreviousIntent));
            } else {
                mBuilder.mActions.add(0, new NotificationCompat.Action(
                        R.drawable.ic_play_arrow_white_24dp, "Play",
                        ppreviousIntent));
            }
        } else {
            if (isPlay) {
                smallViews.setImageViewResource(R.id.status_bar_play, R.drawable.ic_pause_white_24dp);
            } else {
                smallViews.setImageViewResource(R.id.status_bar_play, R.drawable.ic_play_arrow_white_24dp);
            }
        }
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }

    private void getBitmapFromURL() {
        try {
            bitmap = BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    BroadcastReceiver onHeadPhoneDetect = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isPlaying()) {
                togglePlayPause();
            }
        }
    };


    private AudioManager.OnAudioFocusChangeListener onAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
        public void onAudioFocusChange(int focusChange) {
            switch (focusChange) {
                case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) :
                    // Lower the volume while ducking.
                    Setting.exoPlayer_Radio.setVolume(0.2f);
                    break;
                case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) :
                    if (isPlaying()) {
                        togglePlayPause();
                    }
                    break;
                case (AudioManager.AUDIOFOCUS_LOSS) :
                    if (isPlaying()) {
                        togglePlayPause();
                    }
                    break;
                case (AudioManager.AUDIOFOCUS_GAIN) :
                    Setting.exoPlayer_Radio.setVolume(1f);
                    if (isPlaying()) {
                        togglePlayPause();
                    }

                    break;
                default: break;
            }
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public IcyHttpDataSourceFactory icy = new IcyHttpDataSourceFactory.Builder(getUserAgent())
            .setIcyHeadersListener(new IcyHttpDataSource.IcyHeadersListener() {
                @Override
                public void onIcyHeaders(IcyHttpDataSource.IcyHeaders icyHeaders) {

                }
            })
            .setIcyMetadataChangeListener(new IcyHttpDataSource.IcyMetadataListener() {
                @Override
                public void onIcyMetaData(final IcyHttpDataSource.IcyMetadata icyMetadata) {
                    try {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (icyMetadata.getStreamTitle().equals("")) {
                                    Setting.songName = getString(R.string.unknown_song);
                                } else {
                                    Setting.songName = icyMetadata.getStreamTitle();
                                }

                                FmActivity.changeSongName(Setting.songName);

                                try {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        mBuilder.setContentText(Setting.songName);
                                    } else {
                                        smallViews.setTextViewText(R.id.status_bar_artist_name, Setting.songName);
                                    }
                                    mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
                                } catch (Exception e){
                                    e.printStackTrace();
                                }
                            }
                        }, 0);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).build();

    @Override
    public void onDestroy() {
        try {

            Setting.exoPlayer_Radio.stop();
            Setting.exoPlayer_Radio.release();
            Setting.exoPlayer_Radio.removeListener(eventListener);
            try {
                if(mWakeLock.isHeld()) {
                    mWakeLock.release();
                }
                mAudioManager.abandonAudioFocus(onAudioFocusChangeListener);
                unregisterReceiver(onHeadPhoneDetect);
                mAudioManager.unregisterMediaButtonEventReceiver(componentName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }
}