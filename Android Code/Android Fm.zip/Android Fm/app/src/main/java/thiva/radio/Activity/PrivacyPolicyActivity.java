package thiva.radio.Activity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import thiva.radio.Constant.Constant;
import thiva.radio.Methods.Methods;
import thiva.radio.R;
import thiva.radio.SharedPre.Setting;


/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class PrivacyPolicyActivity extends AppCompatActivity {

    private Toolbar toolbarAbout;
    private Methods methods;
    private WebView privacy_policy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Setting.Dark_Mode) {
            setTheme(R.style.AppTheme2);
        } else {
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);

        methods = new Methods(this);
        methods.forceRTLIfSupported(getWindow());

        toolbarAbout = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarAbout);
        setTitle(getResources().getString(R.string.privacy_policy));

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarAbout.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onBackPressed();
            }
        });

        methods.Toolbar_Color(toolbarAbout,getWindow(),getSupportActionBar(),"");
        methods.setStatusBar(getWindow());

        if (Setting.Dark_Mode) {
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_keyboard_backspace_black_24dp);
        } else {
            if (Setting.ToolBar_Color) {
                getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_keyboard_backspace_black_24dp);
            }else {
                getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_keyboard_backspace_black_24dp2);
            }
        }

        privacy_policy = findViewById(R.id.privacy_policy);
        privacy_policy.getSettings().setJavaScriptEnabled(true);
        privacy_policy.loadUrl(Constant.SAVER_URL+"privacy_policy.php");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}