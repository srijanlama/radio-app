package thiva.radio.interfaces;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public interface NemosoftsListener {
    void onStart();
    void onEnd(String success, String verifyStatus, String message);
}