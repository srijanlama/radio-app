package thiva.radio.Methods;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import es.dmoral.toasty.Toasty;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import thiva.radio.R;
import thiva.radio.SharedPre.MY_API;
import thiva.radio.SharedPre.Setting;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class Methods {

    @SerializedName("song_image")
    String song_image = "song_image";
    private Context context;
    private InterstitialAd interstitialAd;
    private com.facebook.ads.InterstitialAd interstitialAdFB;

    @SuppressLint("CommitPrefEdits")

    public Methods(Context context) {
        this.context = context;
        loadad();
    }

    private void loadad() {
        if (Setting.isAdmobInterAd) {
            interstitialAd = new InterstitialAd(context);
            AdRequest adRequest;
            if (ConsentInformation.getInstance(context).getConsentStatus() == ConsentStatus.PERSONALIZED) {
                adRequest = new AdRequest.Builder()
                        .build();
            } else {
                Bundle extras = new Bundle();
                extras.putString("npa", "1");
                adRequest = new AdRequest.Builder()
                        .addNetworkExtrasBundle(AdMobAdapter.class, extras)
                        .build();
            }
            interstitialAd.setAdUnitId(Setting.ad_inter_id);
            interstitialAd.loadAd(adRequest);
        } else if (Setting.isFBInterAd) {
            interstitialAdFB = new com.facebook.ads.InterstitialAd(context, Setting.fb_ad_inter_id);
            interstitialAdFB.loadAd();
        }
    }


    public void showInter() {
        if (Setting.isAdmobInterAd) {
            Setting.adCount = Setting.adCount + 1;
            if (Setting.adCount % Setting.adShow == 0) {
                interstitialAd.setAdListener(new com.google.android.gms.ads.AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                    }
                });
                if (interstitialAd.isLoaded()) {
                    interstitialAd.show();
                }
                loadad();
            }
        } else if (Setting.isFBInterAd) {
            Setting.adCount = Setting.adCount + 1;
            if (Setting.adCount % Setting.adShowFB == 0) {
                interstitialAdFB.loadAd(interstitialAdFB.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
                    @Override
                    public void onError(com.facebook.ads.Ad ad, AdError adError) {

                    }

                    @Override
                    public void onAdLoaded(com.facebook.ads.Ad ad) {

                    }

                    @Override
                    public void onAdClicked(com.facebook.ads.Ad ad) {

                    }

                    @Override
                    public void onLoggingImpression(com.facebook.ads.Ad ad) {

                    }

                    @Override
                    public void onInterstitialDisplayed(com.facebook.ads.Ad ad) {

                    }

                    @Override
                    public void onInterstitialDismissed(com.facebook.ads.Ad ad) {
                    }
                }).build());

                if (interstitialAdFB.isAdLoaded()) {
                    interstitialAdFB.show();
                }
                loadad();
            }
        }
    }

    private void showPersonalizedAds(LinearLayout linearLayout) {
        if (Setting.isAdmobBannerAd) {
            AdView adView = new AdView(context);
            AdRequest adRequest = new AdRequest.Builder().addTestDevice("0336997DCA346E1612B610471A578EEB").build();
            adView.setAdUnitId(Setting.ad_banner_id);
            if (Setting.banner_size.equals("SMART_BANNER")){
                adView.setAdSize(AdSize.SMART_BANNER);
            }else {
                adView.setAdSize(AdSize.BANNER);
            }
            linearLayout.addView(adView);
            adView.loadAd(adRequest);
        } else if (Setting.isFBBannerAd) {
            com.facebook.ads.AdView adView;
            if (Setting.banner_size_fb.equals("BANNER_HEIGHT_90")){
                adView = new com.facebook.ads.AdView(context, Setting.fb_ad_banner_id, com.facebook.ads.AdSize.BANNER_HEIGHT_90);
            }else {
                adView = new com.facebook.ads.AdView(context, Setting.fb_ad_banner_id, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            }
            adView.loadAd();
            linearLayout.addView(adView);
        }
    }

    private void showNonPersonalizedAds(LinearLayout linearLayout) {
        if (Setting.isAdmobBannerAd) {
            Bundle extras = new Bundle();
            extras.putString("npa", "1");
            AdView adView = new AdView(context);
            AdRequest adRequest = new AdRequest.Builder()
                    .addNetworkExtrasBundle(AdMobAdapter.class, extras)
                    .build();
            adView.setAdUnitId(Setting.ad_banner_id);
            if (Setting.banner_size.equals("SMART_BANNER")){
                adView.setAdSize(AdSize.SMART_BANNER);
            }else {
                adView.setAdSize(AdSize.BANNER);
            }
            linearLayout.addView(adView);
            adView.loadAd(adRequest);
        } else if (Setting.isFBBannerAd) {
            com.facebook.ads.AdView adView;
            if (Setting.banner_size_fb.equals("BANNER_HEIGHT_90")){
                adView = new com.facebook.ads.AdView(context, Setting.fb_ad_banner_id, com.facebook.ads.AdSize.BANNER_HEIGHT_90);
            }else {
                adView = new com.facebook.ads.AdView(context, Setting.fb_ad_banner_id, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            }
            adView.loadAd();
            linearLayout.addView(adView);
        }
    }

    public void showBannerAd(LinearLayout linearLayout) {
        if (isNetworkAvailable() && linearLayout != null) {
            if (ConsentInformation.getInstance(context).getConsentStatus() == ConsentStatus.NON_PERSONALIZED) {
                showNonPersonalizedAds(linearLayout);
            } else {
                showPersonalizedAds(linearLayout);
            }
        }
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }




    public void showSnackBar(String message) {
        Toasty.success(context, message, Toast.LENGTH_SHORT, true).show();
    }

    public void showSnackBarError(String message) {
        Toasty.error(context, message, Toast.LENGTH_SHORT, true).show();
    }


    public void Toolbar_Color(Toolbar toolbar, Window window, ActionBar actionBar, String Type) {

        if (Setting.ToolBar_Color) {
            if (Type.equals("Home")){
            }else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    actionBar.setHomeAsUpIndicator(R.drawable.ic_keyboard_backspace_black_24dp);
                    toolbar.setTitleTextColor(ContextCompat.getColor(context, R.color.white));
                }
            }
            switch (Setting.get_color_my){
                case 0: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_1));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_1));
                    }
                    break;
                case 1: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_2));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_2));
                    }
                    break;
                case 2: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_3));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_3));
                    }
                    break;
                case 3: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_4));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_4));
                    }
                    break;
                case 4: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_5));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_5));
                    }
                    break;
                case 5: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_6));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_6));
                    }
                    break;
                case 6: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_7));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_7));
                    }
                    break;
                case 7: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_8));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_8));
                    }
                    break;
                default: toolbar.setBackgroundColor(ContextCompat.getColor(context, R.color.Toolbar_8));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(context.getResources().getColor(R.color.Toolbar_8));
                    }
            }
        }
    }

    public void setStatusBar(Window window) {
        if (Setting.StatusBar){
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    public void Set_color_image(ImageView color_image) {
        switch (Setting.get_color_my){
            case 0: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_1)));
                break;
            case 1: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_2)));
                break;
            case 2: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_3)));
                break;
            case 3: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_4)));
                break;
            case 4: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_5)));
                break;
            case 5: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_6)));
                break;
            case 6: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_7)));
                break;
            case 7: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_8)));
                break;
            default: color_image.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(context, R.color.Toolbar_8)));
        }
    }

    public boolean isConnectingToInternet() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void showToast(String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
    }

    public static long convert_long(String s) {

        long ms = 0;
        Pattern p;
        if (s.contains(("\\:"))) {
            p = Pattern.compile("(\\d+):(\\d+)");
        } else {
            p = Pattern.compile("(\\d+).(\\d+)");
        }
        Matcher m = p.matcher(s);
        if (m.matches()) {
            int h = Integer.parseInt(m.group(1));
            int min = Integer.parseInt(m.group(2));
            // int sec = Integer.parseInt(m.group(2));
            ms = (long) h * 60 * 60 * 1000 + min * 60 * 1000;
        }
        return ms;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public void forceRTLIfSupported(Window window) {
        if (Setting.isRTL) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                window.getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        }
    }


    public static String milliSecondsToTimerDownload(long milliseconds) {
        String finalTimerString = "";
        String hourString = "";
        String secondsString = "";
        String minutesString = "";

        // Convert total duration into time
        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        // Add hours if there

        if (hours != 0) {
            hourString = hours + ":";
        }

        // Prepending 0 to seconds if it is one digit
        if (seconds < 10) {
            secondsString = "0" + seconds;
        } else {
            secondsString = "" + seconds;
        }

        // Prepending 0 to minutes if it is one digit
        if (minutes < 10) {
            minutesString = "0" + minutes;
        } else {
            minutesString = "" + minutes;
        }

        finalTimerString = hourString + minutesString + ":" + secondsString;

        // return timer string
        return finalTimerString;
    }


    public RequestBody getAPIRequest(String method, int page, String Nemosofts_key, String songID, String searchText, String searchType, String catID, String mID, String Name, String istID, String rate, String email, String password, String name, String phone, String userID, String reportMessage, File file) {
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new MY_API());
        jsObj.addProperty("method_name", method);
        jsObj.addProperty("package_name", context.getPackageName());

        switch (method) {
            case Setting.METHOD_SUGGESTION:
                jsObj.addProperty("user_id", userID);
                jsObj.addProperty("song_title", name);
                jsObj.addProperty("message", reportMessage);
                break;
            case Setting.TAG_ROOT:
                jsObj.addProperty("key_id", Nemosofts_key);
                break;
        }

        if (method.equals(Setting.METHOD_SUGGESTION)) {
            final MediaType MEDIA_TYPE_PNG = MediaType.parse("image/*");
            return new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(song_image, file.getName(), RequestBody.create(MEDIA_TYPE_PNG, file))
                    .addFormDataPart("data", MY_API.toBase64(jsObj.toString()))
                    .build();
        } else {
            return new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("data", MY_API.toBase64(jsObj.toString()))
                    .build();
        }
    }

    public String getPathImage(Uri uri) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                String filePath = "";
                String wholeID = DocumentsContract.getDocumentId(uri);

                String id = wholeID.split(":")[1];
                String[] column = {MediaStore.Images.Media.DATA};
                String sel = MediaStore.Images.Media._ID + "=?";

                Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        column, sel, new String[]{id}, null);

                int columnIndex = cursor.getColumnIndex(column[0]);
                if (cursor.moveToFirst()) {
                    filePath = cursor.getString(columnIndex);
                }
                cursor.close();
                return filePath;
            } else {

                if (uri == null) {
                    return null;
                }
                String[] projection = {MediaStore.Images.Media.DATA};
                Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null) {
                    int column_index = cursor
                            .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                    cursor.moveToFirst();
                    String retunn = cursor.getString(column_index);
                    cursor.close();
                    return retunn;
                }
                return uri.getPath();
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (uri == null) {
                return null;
            }
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
            if (cursor != null) {
                int column_index = cursor
                        .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                String returnn = cursor.getString(column_index);
                cursor.close();
                return returnn;
            }
            return uri.getPath();
        }
    }

    public void getVerifyDialog(String title, String message) {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context, R.style.ThemeDialog);
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setCancelable(false);

        alertDialog.setPositiveButton(context.getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alertDialog.show();
    }
}
