package thiva.radio.SharedPre;

import android.annotation.SuppressLint;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.Random;

import thiva.radio.Constant.Constant;
import thiva.radio.R;


/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class MYRecord {

    private Context context;

    @SuppressLint("CommitPrefEdits")
    public MYRecord(Context context) {
        this.context = context;
    }

    public void Stard_Record() {
        new Record().execute(new Void[0]);
    }

    public void Stop_Record() {
        try {
            Setting.fileOutputStream.flush();
            Setting.fileOutputStream.close();
            Setting.inputStream.close();
        } catch (Exception e) {

        }
    }

    @SuppressLint("StaticFieldLeak")
    class Record extends AsyncTask<Void, Void, StringBuilder> {
        Record() {
        }

        protected StringBuilder doInBackground(Void... voids) {
            String LOG_TAG = "TAG_ofcurrentdata";
            try {
                StringBuilder outputSource = new StringBuilder();
                outputSource.append(file());

                String os;
                os = outputSource.toString();
                Setting.inputStream = new URL(Setting.Url_fm).openStream();

                Log.d(LOG_TAG, "url.openStream()");
                Setting.fileOutputStream = new FileOutputStream(os);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("FileOutputStream: ");
                stringBuilder.append(os);
                Log.d(LOG_TAG, stringBuilder.toString());

                while (true) {
                    int l;
                    byte[] buffer = new byte[256];
                    Log.d("buffer.print", "" + buffer);
                    while ((l = Setting.inputStream.read(buffer)) != -1) {
                        Log.d(LOG_TAG, "in while" + buffer);
                        Log.d(LOG_TAG, "in while" + l);
                        Setting.fileOutputStream.write(buffer, 0, l);
                    }
                }
            } catch (Exception e) {
                StringBuilder stringBuilder3 = new StringBuilder();
                Log.d(LOG_TAG, "in catch" + e);
                stringBuilder3.append("");
                stringBuilder3.append("");
                return stringBuilder3;
            }
        }

        @SuppressLint("WrongConstant")
        protected void onPostExecute(StringBuilder s) {
            super.onPostExecute(s);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Done");
            stringBuilder.append(s);
            Toast.makeText(context, stringBuilder.toString(), 1).show();
            context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(new File(String.valueOf(s)))));
        }
    }

    @NonNull
    private File file() {
        String iconsStoragePath = Environment.getExternalStorageDirectory() + "/" + context.getString(R.string.app_name) + "/";
        File sdIconStorageDir = new File(iconsStoragePath);
        if (!sdIconStorageDir.exists()) {
            sdIconStorageDir.mkdir();
        }
        Random generator = new Random();
        int n = 10000;
        n = generator.nextInt(n);
        String fname = "Recording-" + n;
        String file_name = fname + ".wav";
        return new File(iconsStoragePath, file_name);
    }
}
