package thiva.radio.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Handler;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import thiva.radio.BuildConfig;

import thiva.radio.R;
import thiva.radio.asyncTask.LoadNemosofts;
import thiva.radio.interfaces.NemosoftsListener;
import thiva.radio.SharedPre.Setting;
import thiva.radio.SharedPre.SharedPref;
import thiva.radio.asyncTask.LoadAbout;
import thiva.radio.interfaces.AboutListener;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class SplashActivity extends AppCompatActivity {

    private SharedPref sharedPref;
    private static int SPLASH_TIME_OUT = 2000;
    private CardView Logo;
    private Animation animation;
    private TextView Logo_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPref = new SharedPref(this);
        if (sharedPref.getNightMode()) {
            Setting.Dark_Mode = true;
            setTheme(R.style.AppTheme2);
        } else {
            Setting.Dark_Mode = false;
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        animation = AnimationUtils.loadAnimation(this, R.anim.smalltobig);

        Logo = findViewById(R.id.logo);
        Logo.startAnimation(animation);
        Logo_text = findViewById(R.id.logo_text);
        Logo_text.startAnimation(animation);

        if (sharedPref.getStatusBar()) {
            Setting.StatusBar = true;
        } else {
            Setting.StatusBar = false;
        }
        Setting.get_color_my = sharedPref.getColor_my();

        if (sharedPref.getToolbar_Color()) {
            Setting.ToolBar_Color = true;
        } else {
            Setting.ToolBar_Color = false;
        }

        if (PlayService.getInstance() != null) {
            Intent main = new Intent(SplashActivity.this, FmActivity.class);
            startActivity(main);
            finish();
        }else {
            if (isNetworkAvailable(SplashActivity.this)) {
                loadAboutData();
            } else {
                IntActivity();
            }
        }
    }

    public void loadAboutData() {
        LoadAbout loadAbout = new LoadAbout(SplashActivity.this, new AboutListener() {
            @Override public void onStart() { }
            @Override
            public void onEnd(String success, String verifyStatus, String message) {
                if (success.equals("1")) { if (!verifyStatus.equals("-1")) { Loadnemosofts();
                } else { errorDialog(getString(R.string.error_unauth_access), message); } } else { errorDialog(getString(R.string.server_error), getString(R.string.err_server)); }
            }
        });
        loadAbout.execute();
    }

    private void thiva() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent main = new Intent(SplashActivity.this, FmActivity.class);
                startActivity(main);
                finish();
            }
        },SPLASH_TIME_OUT);

    }

    private void IntActivity() {
        Intent main = new Intent(SplashActivity.this, intActivity.class);
        startActivity(main);
        finish();
    }

    public static boolean isNetworkAvailable(Context activity) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void Loadnemosofts() {
        if (sharedPref.getIsFirstPurchaseCode()) {
            LoadNemosofts loadAbout = new LoadNemosofts(SplashActivity.this, new NemosoftsListener() {
                @Override
                public void onStart() {
                }
                @Override
                public void onEnd(String success, String verifyStatus, String message) {
                    if (success.equals("1")) {
                        if (!verifyStatus.equals("-1")) { if (BuildConfig.APPLICATION_ID.equals(Setting.itemAbout.getPackage_name())) { sharedPref.setIsFirstPurchaseCode(false);sharedPref.setPurchaseCode(Setting.itemAbout);thiva(); } else { errorDialog(getString(R.string.error_nemosofts_key), getString(R.string.create_nemosofts_key)); } } else { errorDialog(getString(R.string.error_nemosofts_key), message); }
                    } else { errorDialog(getString(R.string.err_internet_not_conn), getString(R.string.error_connect_net_tryagain));
                    }
                }
            });
            loadAbout.execute();
        } else {
            sharedPref.getPurchaseCode();
            thiva();
        }
    }

    private void errorDialog(String title, String message) {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(SplashActivity.this, R.style.ThemeDialog);
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setCancelable(false);

        if (title.equals(getString(R.string.err_internet_not_conn)) || title.equals(getString(R.string.server_error))) {
            alertDialog.setNegativeButton(getString(R.string.try_again), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Loadnemosofts();
                }
            });
        }

        alertDialog.setPositiveButton(getString(R.string.exit), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        alertDialog.show();
    }
}