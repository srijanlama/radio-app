package thiva.radio.Activity;

import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FilenameFilter;
import java.text.DecimalFormat;
import java.util.ArrayList;

import thiva.radio.Activity.Recorder.AdapterRecorder;
import thiva.radio.Activity.Recorder.ClickListenerRecorder;
import thiva.radio.Activity.Recorder.ItemRecorder;
import thiva.radio.Methods.Methods;
import thiva.radio.R;
import thiva.radio.SharedPre.Setting;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class RecorderActivity extends AppCompatActivity{

    private Toolbar toolbar;
    private RecyclerView rv;
    private AdapterRecorder adapter;
    private ArrayList<ItemRecorder> arrayList;
    private ProgressBar progressbar;
    private Methods methods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Setting.Dark_Mode) {
            setTheme(R.style.AppTheme2);
        } else {
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recorder);

        methods = new Methods(this);
        methods.showInter();
        methods.forceRTLIfSupported(getWindow());

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.recording));

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        methods.Toolbar_Color(toolbar,getWindow(),getSupportActionBar(), "");
        methods.setStatusBar(getWindow());

        arrayList = new ArrayList<>();
        progressbar = findViewById(R.id.progressbar);
        rv = findViewById(R.id.rv_song_by_cat);
        LinearLayoutManager llm = new LinearLayoutManager(RecorderActivity.this);
        rv.setLayoutManager(llm);
        rv.setItemAnimator(new DefaultItemAnimator());
        rv.setHasFixedSize(true);

        try {
            new LoadDownloadSongs().execute();
        } catch (Exception e) {
            e.printStackTrace();
        }

        LinearLayout AdView = findViewById(R.id.adView1);
        methods.showBannerAd(AdView);
    }

    class LoadDownloadSongs extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            arrayList.clear();
            progressbar.setVisibility(View.VISIBLE);
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                loadDownloaded();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            if (RecorderActivity.this != null) {
                setAdapter();
            }else {
                progressbar.setVisibility(View.GONE);
            }
        }
    }

    private void loadDownloaded() {
        String iconsStoragePath = Environment.getExternalStorageDirectory() + "/" + getString(R.string.app_name) + "/";
        File root = new File(iconsStoragePath);

        File[] songs = root.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.endsWith(".wav");
            }
        });

        if (songs != null) {
            for (int i = 0; i < songs.length; i++) {
                MediaMetadataRetriever md = new MediaMetadataRetriever();
                md.setDataSource(songs[i].getAbsolutePath());
                String title = songs[i].getName();
                String duration = md.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);

                duration = methods.milliSecondsToTimerDownload(Long.parseLong(duration));
                String url = songs[i].getAbsolutePath();
                long filesize = songs[i].length();

                arrayList.add(new ItemRecorder(String.valueOf(i), url, title, duration, filesize));

                Setting.arrayList_play_rc.clear();
                Setting.arrayList_play_rc.addAll(arrayList);
                Setting.playPos_rc= 0;
            }
        }

    }



    private void setAdapter() {
        adapter = new AdapterRecorder(RecorderActivity.this, arrayList, new ClickListenerRecorder() {
            @Override
            public void onClick(int position) {
                Setting.arrayList_play_rc.clear();
                Setting.arrayList_play_rc.addAll(arrayList);
                Setting.playPos_rc = position;

                adapter.notifyDataSetChanged();

                Intent STOP = new Intent(RecorderActivity.this, PlayService.class);
                if (PlayService.getInstance() != null) {
                    STOP.setAction(PlayService.ACTION_STOP);
                    startService(STOP);
                }
            }
        }, "");
        rv.setAdapter(adapter);
        progressbar.setVisibility(View.GONE);

    }


    @Override
    public void onDestroy() {
        try {
            Setting.exoPlayer.stop();
            Setting.exoPlayer.release();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                try {
                    Setting.exoPlayer.stop();
                    Setting.exoPlayer.release();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;

            default:
                return super.onOptionsItemSelected(menuItem);
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        try {
            Setting.exoPlayer.stop();
            Setting.exoPlayer.release();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onBackPressed();
    }
}