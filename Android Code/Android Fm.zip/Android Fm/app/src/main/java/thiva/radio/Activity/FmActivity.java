package thiva.radio.Activity;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.navigation.NavigationView;
import com.nemosofts.library.chibde.visualizer.BarVisualizer;
import com.shawnlin.numberpicker.NumberPicker;

import java.util.Calendar;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import thiva.radio.BuildConfig;
import thiva.radio.Methods.Methods;
import thiva.radio.R;
import thiva.radio.Receiver.MyReceiver;
import thiva.radio.SharedPre.MYRecord;
import thiva.radio.SharedPre.Setting;
import thiva.radio.SharedPre.SharedPref;
import thiva.radio.asyncTask.LoadUpdate;
import thiva.radio.interfaces.AboutListener;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class FmActivity extends AppCompatActivity   implements NavigationView.OnNavigationItemSelectedListener{

    public static ImageView imageView_timer, imageView_play, imageView_record;
    public static ProgressBar progressBar;
    public static TextView  textView_timer, textView_stoptimer, textView_song, textView_play;
    private Methods methods;
    private SharedPref sharedPref;
    private SeekBar volumeSeekBar;
    private AudioManager audioManager;
    private ImageView imageView;
    private TextView titleWelcome;
    private DrawerLayout drawer;
    public static BarVisualizer barVisualizer;
    private Toolbar toolbar;
    private MYRecord myRecord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Setting.Dark_Mode) {
            setTheme(R.style.AppTheme2);
        } else {
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myRecord = new  MYRecord(this);

        methods = new Methods(this);
        sharedPref = new SharedPref(this);
        methods.forceRTLIfSupported(getWindow());

        imageView = findViewById(R.id.imagehome);
        titleWelcome = findViewById(R.id.title_welcome);

        if (Setting.purchase_code.equals(Setting.itemAbout.getPurchase_code())) {
            titleWelcome.setText(getTimeOfTheDay());
        }



        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        methods.Toolbar_Color(toolbar,getWindow(),getSupportActionBar(),"Home");

        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(GravityCompat.START);
            }
        });
        if (Setting.Dark_Mode) {
            toggle.setHomeAsUpIndicator(R.drawable.ic_menu2);
        } else {
            if (Setting.ToolBar_Color) {
                toggle.setHomeAsUpIndicator(R.drawable.ic_menu2);
                toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.white));
            }else {
                toggle.setHomeAsUpIndicator(R.drawable.ic_menu1);
            }

        }

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        toggle.setDrawerIndicatorEnabled(false);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        barVisualizer = findViewById(R.id.visualizer);
        if (Setting.visualizer){
            if (checkVisualizer()) {
                if (PlayService.getInstance() != null) {
                    //TODO: init MediaPlayer and play the audio
                    //get the AudioSessionId from your MediaPlayer and pass it to the visualizer
                    int audioSessionId = Setting.exoPlayer_Radio.getAudioSessionId();
                    if (audioSessionId != -1){
                        FmActivity.barVisualizer.setColor(ContextCompat.getColor(this, R.color.colorAccent_Light));
                        FmActivity.barVisualizer.setDensity(50);
                        try {
                            FmActivity.barVisualizer.setPlayer(audioSessionId);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        }

        progressBar = findViewById(R.id.ProgressBar);
        imageView_timer = findViewById(R.id.imageView_timer);
        imageView_play =findViewById(R.id.imageView_play);
        imageView_record = findViewById(R.id.imageView_record);
        textView_timer = findViewById(R.id.textView_timer);
        textView_stoptimer = findViewById(R.id.textView_stoptimer);
        textView_song = findViewById(R.id.textView_song);
        textView_play = findViewById(R.id.textView_play);
        progressBar.setVisibility(View.GONE);


        if (!Setting.canRecordNew) {
            if (Setting.Dark_Mode) {
                imageView_record.setImageResource(R.drawable.ic_microphone_b);
            } else {
                imageView_record.setImageResource(R.drawable.ic_microphone_b2);
            }
        }else {
            if (Setting.Dark_Mode) {
                imageView_record.setImageResource(R.drawable.ic_microphone2);
            } else {
                imageView_record.setImageResource(R.drawable.ic_microphone);
            }
        }

        imageView_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FmActivity.this, PlayService.class);
                if (PlayService.getInstance() != null) {
                    intent.setAction(PlayService.ACTION_TOGGLE);
                    if (Setting.exoPlayer_Radio.getPlayWhenReady()) {
                        if (!Setting.canRecordNew) {
                            myRecord.Stop_Record();
                            if (Setting.Dark_Mode) {
                                imageView_record.setImageResource(R.drawable.ic_microphone2);
                            } else {
                                imageView_record.setImageResource(R.drawable.ic_microphone);
                            }
                            methods.showSnackBar(getResources().getString(R.string.recording_complite));
                            Setting.canRecordNew = true;
                        }
                    }
                } else {
                    PlayService.createInstance().initialize(FmActivity.this);
                    intent.setAction(PlayService.ACTION_PLAY);
                }
               startService(intent);
            }
        });

        imageView_timer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!sharedPref.getIsSleepTimeOn()) {
                    timer();
                } else {
                    openCancelTimerDialog();
                }
            }
        });

        imageView_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkRecord()){
                    if (Setting.canRecordNew) {
                        if (PlayService.getInstance() != null && PlayService.getInstance().isPlaying()) {
                            Setting.canRecordNew = false;
                            myRecord.Stard_Record();
                            if (Setting.Dark_Mode) {
                                imageView_record.setImageResource(R.drawable.ic_microphone_b);
                            } else {
                                imageView_record.setImageResource(R.drawable.ic_microphone_b2);
                            }
                            methods.showSnackBar(getResources().getString(R.string.recording_start));
                        } else {
                            methods.showSnackBarError(getResources().getString(R.string.not_start_fm));
                        }
                    } else {
                        myRecord.Stop_Record();
                        if (Setting.Dark_Mode) {
                            imageView_record.setImageResource(R.drawable.ic_microphone2);
                        } else {
                            imageView_record.setImageResource(R.drawable.ic_microphone);
                        }
                        methods.showSnackBar(getResources().getString(R.string.recording_complite));
                        Setting.canRecordNew = true;
                    }
                }
            }
        });

        sharedPref.setCheckSleepTime();
        setIfPlaying();

        volumeSeekBar = findViewById(R.id.seekBar);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        volumeSeekBar.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        volumeSeekBar.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        volumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                try {
                    audioManager.setStreamVolume(Setting.exoPlayer_Radio.getAudioStreamType(), i, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, i, 0);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        PermissionDialog();
        Update();

        LinearLayout AdView = findViewById(R.id.adView3);
        methods.showBannerAd(AdView);
    }

    private String getTimeOfTheDay() {
        String message = getString(R.string.title_good_day);
        Calendar c = Calendar.getInstance();
        int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

        String[] images = new String[]{};
        if (timeOfDay >= 0 && timeOfDay < 6) {
            message = getString(R.string.title_good_night);
            images = getResources().getStringArray(R.array.night);
        } else if (timeOfDay >= 6 && timeOfDay < 12) {
            message = getString(R.string.title_good_morning);
            images = getResources().getStringArray(R.array.morning);
        } else if (timeOfDay >= 12 && timeOfDay < 16) {
            message = getString(R.string.title_good_afternoon);
            images = getResources().getStringArray(R.array.after_noon);
        } else if (timeOfDay >= 16 && timeOfDay < 20) {
            message = getString(R.string.title_good_evening);
            images = getResources().getStringArray(R.array.evening);
        } else if (timeOfDay >= 20 && timeOfDay < 24) {
            message = getString(R.string.title_good_night);
            images = getResources().getStringArray(R.array.night);
        }
        String day = images[new Random().nextInt(images.length)];
        loadTimeImage(day);
        return message;
    }

    private void loadTimeImage(String day) {
        Glide.with(this)
                .load(day)
                .placeholder(R.drawable.material_design_default)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(imageView);
    }

    public static void setBuffer(Boolean flag) {
        if (flag) {
            progressBar.setVisibility(View.VISIBLE);
            imageView_play.setVisibility(View.INVISIBLE);
        } else {
            progressBar.setVisibility(View.INVISIBLE);
            imageView_play.setVisibility(View.VISIBLE);
        }
    }

    public static void changeSongName(String songName) {
        textView_song.setText(songName);
    }

    public void setIfPlaying() {
        if (PlayService.getInstance() != null) {
            PlayService.initNewContext(FmActivity.this);
            textView_song.setText(Setting.songName);
            changePlayPause(PlayService.getInstance().isPlaying());
        } else {
            changePlayPause(false);
        }
    }

    private void PermissionDialog() {
        if (Setting.visualizer){
            if (sharedPref.getCheckPermission()){
                if (!checkVisualizer()) {
                    final AlertDialog.Builder alert;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        if (Setting.Dark_Mode){
                            alert = new AlertDialog.Builder(FmActivity.this, R.style.ThemeDialog2);
                        }else {
                            alert = new AlertDialog.Builder(FmActivity.this, R.style.ThemeDialog);
                        }
                    } else {
                        alert = new AlertDialog.Builder(FmActivity.this);
                    }
                    alert.setTitle(getString(R.string.permissions_required));
                    alert.setMessage(getString(R.string.set_permission));
                    alert.setPositiveButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            sharedPref.setCheckPermission(false);
                        }
                    });
                    alert.setNegativeButton(getString(R.string.permission_granted), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (checkVisualizer_true()) {
                            }
                        }
                    });
                    alert.show();
                }
            }
        }

    }

    private void changePlayPause(Boolean play) {
        if (play) {
            imageView_play.setImageDrawable(ContextCompat.getDrawable(FmActivity.this, R.drawable.ic_pause_white_24dp));
            textView_play.setText(getResources().getString(R.string.textView_pause));
        } else {
            imageView_play.setImageDrawable(ContextCompat.getDrawable(FmActivity.this, R.drawable.ic_play_arrow_white_24dp));
            textView_play.setText(getResources().getString(R.string.textView_play));
        }
        if (Setting.autoplay){
            if (PlayService.getInstance() != null) {
            } else {
                Intent intent = new Intent(FmActivity.this, PlayService.class);
                if (PlayService.getInstance() != null) {
                } else {
                    PlayService.createInstance().initialize(FmActivity.this);
                    intent.setAction(PlayService.ACTION_PLAY);
                }
                startService(intent);
            }
        }

    }

    public Boolean checkVisualizer() {
        if ((ContextCompat.checkSelfPermission(FmActivity.this, "android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED)) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean checkRecord() {
        if ((ContextCompat.checkSelfPermission(FmActivity.this, "android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"},
                        101);
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public Boolean checkVisualizer_true() {
        if ((ContextCompat.checkSelfPermission(FmActivity.this, "android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{"android.permission.RECORD_AUDIO"},
                        101);
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public void timer() {

        final Dialog dialog = new Dialog(FmActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);

        final NumberPicker hours_picker = dialog.findViewById(R.id.hours_picker);
        final NumberPicker minute_picker = dialog.findViewById(R.id.minute_picker);
        Button button = dialog.findViewById(R.id.button_dialog);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String hours = String.valueOf(hours_picker.getValue());
                String minute = String.valueOf(minute_picker.getValue());

                String totalTime = hours + ":" + minute;
                long total_timer = Methods.convert_long(totalTime) + System.currentTimeMillis();

                Random random = new Random();
                int id = random.nextInt(100);

                sharedPref.setSleepTime(true, total_timer, id);

                Intent intent = new Intent(FmActivity.this, MyReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(FmActivity.this, id, intent, PendingIntent.FLAG_ONE_SHOT);
                AlarmManager alarmManager = (AlarmManager) FmActivity.this.getSystemService(ALARM_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, total_timer, pendingIntent);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, total_timer, pendingIntent);
                }
                updateTimer(total_timer);

                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void updateTimer(final long time) {
        long timeleft = time - System.currentTimeMillis();
        if (timeleft > 0) {
            String hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(timeleft),
                    TimeUnit.MILLISECONDS.toMinutes(timeleft) % TimeUnit.HOURS.toMinutes(1),
                    TimeUnit.MILLISECONDS.toSeconds(timeleft) % TimeUnit.MINUTES.toSeconds(1));

            textView_stoptimer.setVisibility(View.GONE);
            textView_timer.setVisibility(View.VISIBLE);
            textView_timer.setText(hms);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (sharedPref.getIsSleepTimeOn()) {
                        updateTimer(time);
                    } else {
                        textView_stoptimer.setVisibility(View.VISIBLE);
                        textView_timer.setVisibility(View.GONE);
                    }
                }
            }, 1000);
        } else {
            textView_stoptimer.setVisibility(View.VISIBLE);
            textView_timer.setVisibility(View.GONE);
        }
    }

    private void openCancelTimerDialog() {
        AlertDialog.Builder alert;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Setting.Dark_Mode){
                alert = new AlertDialog.Builder(FmActivity.this, R.style.ThemeDialog2);
            }else {
                alert = new AlertDialog.Builder(FmActivity.this, R.style.ThemeDialog);
            }
        } else {
            alert = new AlertDialog.Builder(FmActivity.this);
        }

        alert.setTitle(getString(R.string.cancel_timer));
        alert.setMessage(getString(R.string.sure_cancel_timer));
        alert.setPositiveButton(getString(R.string.stop), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                textView_stoptimer.setVisibility(View.VISIBLE);
                textView_timer.setVisibility(View.GONE);

                Intent intent = new Intent(FmActivity.this, MyReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(FmActivity.this, sharedPref.getSleepID(), intent, PendingIntent.FLAG_ONE_SHOT);
                AlarmManager alarmManager = (AlarmManager) FmActivity.this.getSystemService(Context.ALARM_SERVICE);
                pendingIntent.cancel();
                alarmManager.cancel(pendingIntent);
                sharedPref.setSleepTime(false, 0, 0);
            }
        });
        alert.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        alert.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.min, menu);
        // Inflate switch
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        // Get state from preferences

        //noinspection SimplifiableIfStatement
        if (id == R.id.nav_help) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.putExtra(Intent.EXTRA_SUBJECT,getString(R.string.app_name));
            Uri data = Uri.parse("mailto:"+Setting.email);
            intent.setData(data);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder alert;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Setting.Dark_Mode){
                alert = new AlertDialog.Builder(FmActivity.this, R.style.ThemeDialog2);
            }else {
                alert = new AlertDialog.Builder(FmActivity.this, R.style.ThemeDialog);
            }
        } else {
            alert = new AlertDialog.Builder(FmActivity.this);
        }

        alert.setTitle(getString(R.string.exit));
        alert.setMessage(getString(R.string.sure_exit));
        alert.setPositiveButton(getString(R.string.exit), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alert.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        alert.show();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        }else if (id == R.id.nav_equalizer) {
            if (PlayService.getInstance() != null){
                Intent eq = new Intent(FmActivity.this, EqualizerActivity.class);
                startActivity(eq);
            }else {
                methods.showSnackBarError(getResources().getString(R.string.not_start_fm));
            }
        }else if (id == R.id.nav_facebook) {
            openFbUrl(Setting.facebook_url);
            methods.showInter();
        }else if (id == R.id.nav_twitter) {
            openWebView(Setting.twiter_url);
            methods.showInter();
        }else if (id == R.id.nav_instagram) {
            methods.showInter();
            openWebView(Setting.intagram_url);
        } else if (id == R.id.nav_web) {
            openWebView(Setting.website);
            methods.showInter();
        }else if (id == R.id.nav_contact) {
            String contact = Setting.contact; // use country code with your phone number
            String url = "https://api.whatsapp.com/send?phone=" + contact;
            try {
                PackageManager pm = getPackageManager();
                pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            } catch (PackageManager.NameNotFoundException e) {
                methods.showSnackBarError("Whatsapp app not installed in your phone");
                e.printStackTrace();
            }
        }else if (id == R.id.nav_rec) {
            if (checkRecord()) {
                Intent eq = new Intent(FmActivity.this, RecorderActivity.class);
                startActivity(eq);
            }
        }else if (id == R.id.nav_set) {
            overridePendingTransition(0, 0);
            overridePendingTransition(0, 0);
            startActivity(new Intent(FmActivity.this, SettingActivity.class));
            finish();
        }
        DrawerLayout drawer =  findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void openWebView(String url){
        Intent intent = new Intent(getApplicationContext(), WebActivity.class);
        intent.putExtra("URL",url);
        startActivity(intent);
    }

    protected void openFbUrl(String username){
        Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
        String facebookUrl = getFacebookPageURL(username);
        facebookIntent.setData(Uri.parse(facebookUrl));
        startActivity(facebookIntent);
    }

    public String getFacebookPageURL(String username) {
        String FACEBOOK_URL = "https://www.facebook.com/"+username;
        PackageManager packageManager = getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                return "fb://facewebmodal/f?href=" + FACEBOOK_URL;
            } else { //older versions of fb app
                return "fb://page/" + username;
            }
        } catch (PackageManager.NameNotFoundException e) {
            return FACEBOOK_URL; //normal web url
        }
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN){
            try {
                volumeSeekBar.setProgress(audioManager.getStreamVolume(Setting.exoPlayer_Radio.getAudioStreamType()));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP){
            try {
                volumeSeekBar.setProgress(audioManager.getStreamVolume(Setting.exoPlayer_Radio.getAudioStreamType()));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (barVisualizer != null)
            barVisualizer.release();
    }

    private void Update() {
        if (methods.isNetworkAvailable()) {
            LoadUpdate loadUpdate = new LoadUpdate(FmActivity.this, new AboutListener() {
                @Override public void onStart() { }
                @Override
                public void onEnd(String success, String verifyStatus, String message) {
                    if (success.equals("1")) {
                        if (!verifyStatus.equals("-1")) {
                            update();
                        }
                    }
                }
            });
            loadUpdate.execute();
        }
    }

    public void update() {
        final Dialog dialog;
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_update);

        final ImageView imageView = dialog.findViewById(R.id.cancel);
        final TextView app_name = dialog.findViewById(R.id.app_name);
        final TextView t1 = dialog.findViewById(R.id.t1);
        final TextView t2 = dialog.findViewById(R.id.t2);
        final TextView t3 = dialog.findViewById(R.id.t3);
        final TextView textView = dialog.findViewById(R.id.text_view_go_pro);

        app_name.setText(getResources().getString(R.string.app_name));
        t1.setText("Version Code "+ Setting.version);
        t2.setText("Version Name "+ Setting.version_name);
        t3.setText(Setting.description);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Setting.url)));
            }
        });

        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        if (BuildConfig.VERSION_CODE != Setting.version){
            if(!BuildConfig.VERSION_NAME.equals(Setting.version_name)){
                dialog.show();
            }
        }
        Window window = dialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

}