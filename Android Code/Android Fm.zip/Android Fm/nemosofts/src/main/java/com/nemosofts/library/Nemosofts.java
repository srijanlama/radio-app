package com.nemosofts.library;

import android.content.Context;

/**
 * Company : Nemosofts
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Thivakaran
 * Contact : info.nemosofts@gmail.com
 * Website : https://nemosofts.com
 */

public class Nemosofts {

    private Context context;

    public Nemosofts(Context context) {
        this.context = context;
    }
}
